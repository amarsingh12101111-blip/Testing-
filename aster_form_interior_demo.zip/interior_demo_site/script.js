const menu = document.querySelector(".menu-btn");
const nav = document.querySelector("#site-nav");
if (menu) {
  menu.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });
}
const form = document.querySelector("#contact-form");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const status = document.querySelector("#form-status");
    if (!form.checkValidity()) {
      status.textContent = "Please complete the required fields and consent before submitting.";
      form.reportValidity();
      return;
    }
    status.textContent = "Demo only: no information was transmitted or stored. Connect this form to a compliant backend before publishing.";
    form.reset();
  });
}
